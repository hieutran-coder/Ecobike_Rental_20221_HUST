package EcoBikeRental.Dto;

/**
 * Description: Class Dto contain info of transaction of body to send request to Interbank
 *
 */
public class RequestTransactionDto {
	private String command;
	private String cardCode;
	private String owner;
	private String cvvCode;
	private String dateExpired;
	private String transactionContent;
	private Long amount;
	private String createdAt;
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public String getCardCode() {
		return cardCode;
	}
	public void setCardCode(String cardCode) {
		this.cardCode = cardCode;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getCvvCode() {
		return cvvCode;
	}
	public void setCvvCode(String cvvCode) {
		this.cvvCode = cvvCode;
	}
	public String getDateExpired() {
		return dateExpired;
	}
	public void setDateExpired(String dateExpired) {
		this.dateExpired = dateExpired;
	}
	public String getTransactionContent() {
		return transactionContent;
	}
	public void setTransactionContent(String transactionContent) {
		this.transactionContent = transactionContent;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
}
